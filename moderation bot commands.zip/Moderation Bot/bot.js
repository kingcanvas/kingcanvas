const Discord = require('discord.js'); // make sure to do "npm i discord.js" so the bot works
const { Client, GatewayIntentBits, EmbedBuilder, SlashCommandBuilder } = require('discord.js');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildBans,
    ],
});

const config = {
    token: 'BOT-TOKEN', // replace with your bot token
    modRoles: [STAFF-ROLE-ID], // Put in staff roles
    modLogChannel: 'LOG-CHANNEL', // Put your log channel ID here
};

client.on('ready', async () => {
    console.log("Bot: Made by KingCanvas: Need help? Join the discord. https://discord.gg/FrxtnNSraF");
    console.log(`Logged in as ${client.user.tag}!`);
    client.user.setPresence({ activities: [{ name: 'Made by KingCanvas', type: 0 }], status: 'online' });

    // Slash commands
    const commands = [
        new SlashCommandBuilder()
            .setName('kick')
            .setDescription('Kicks a user from the server.')
            .addUserOption(option =>
                option.setName('user').setDescription('The user to kick.').setRequired(true)
            )
            .addStringOption(option =>
                option.setName('reason').setDescription('The reason for the kick.')
            ),
        new SlashCommandBuilder()
            .setName('ban')
            .setDescription('Bans a user from the server.')
            .addUserOption(option =>
                option.setName('user').setDescription('The user to ban.').setRequired(true)
            )
            .addStringOption(option =>
                option.setName('reason').setDescription('The reason for the ban.')
            ),
        new SlashCommandBuilder()
            .setName('warn')
            .setDescription('Warns a user.')
            .addUserOption(option =>
                option.setName('user').setDescription('The user to warn.').setRequired(true)
            )
            .addStringOption(option =>
                option.setName('reason').setDescription('The reason for the warn.')
            ),
    ];

    try {
        await client.application.commands.set(commands, config.guildId); 
        console.log('Successfully registered application commands.');
    } catch (error) {
        console.error('Error registering application commands:', error);
    }
});

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isCommand()) return;

    if (!interaction.member.roles.cache.some(role => config.modRoles.includes(role.id)) && !interaction.member.permissions.has('ADMINISTRATOR')) {
        return interaction.reply({ content: 'You do not have permission to use moderation commands.', ephemeral: true });
    }

    const { commandName, options } = interaction;

    if (commandName === 'kick') {
        const user = options.getMember('user');
        const reason = options.getString('reason') || 'No reason provided.';

        try {
            await user.kick(reason);
            interaction.reply(`Kicked ${user.user.tag}. Reason: ${reason}`);
            logModAction(interaction.guild, interaction.user, 'Kick', user.user, reason);
        } catch (error) {
            console.error(error);
            interaction.reply({ content: 'Failed to kick user.', ephemeral: true });
        }
    } else if (commandName === 'ban') {
        const user = options.getMember('user');
        const reason = options.getString('reason') || 'No reason provided.';

        try {
            await user.ban({ reason });
            interaction.reply(`Banned ${user.user.tag}. Reason: ${reason}`);
            logModAction(interaction.guild, interaction.user, 'Ban', user.user, reason);
        } catch (error) {
            console.error(error);
            interaction.reply({ content: 'Failed to ban user.', ephemeral: true });
        }
    } else if (commandName === 'warn') {
        const user = options.getMember('user');
        const reason = options.getString('reason') || 'No reason provided.';

        try {
            await user.send(`You have been warned in ${interaction.guild.name}. Reason: ${reason}`);
            interaction.reply(`${user.user.tag} has been warned. Reason: ${reason}`);
            logModAction(interaction.guild, interaction.user, 'Warn', user.user, reason);
        } catch (error) {
            console.error(error);
            interaction.reply(`${user.user.tag} has been warned. Reason: ${reason} (Could not message user)`);
            logModAction(interaction.guild, interaction.user, 'Warn', user.user, reason);
        }
    }
});

function logModAction(guild, moderator, action, target, reason) {
    if (!config.modLogChannel) return;

    const logChannel = guild.channels.cache.get(config.modLogChannel);
    if (!logChannel) return;

    const embed = new EmbedBuilder()
        .setColor('#FF0000')
        .setTitle(`Moderation Action: ${action}`)
        .addFields(
            { name: 'Moderator', value: moderator.tag },
            { name: 'Target', value: target.tag },
            { name: 'Reason', value: reason }
        )
        .setTimestamp();

    logChannel.send({ embeds: [embed] });
}

client.login(config.token);