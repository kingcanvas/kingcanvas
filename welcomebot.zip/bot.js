const { Client, GatewayIntentBits } = require('discord.js');
const { config } = require('dotenv');

config();

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.MessageContent,
    ],
});

const BOT_TOKEN = process.env.BOT_TOKEN;
const WELCOME_CHANNEL_ID = process.env.WELCOME_CHANNEL_ID;

if (!BOT_TOKEN) {
    console.error('Bot token is missing. Make sure to set the BOT_TOKEN environment variable in your .env file.');
    process.exit(1);
}

if (!WELCOME_CHANNEL_ID) {
    console.error('Welcome channel ID is missing. Make sure to set the WELCOME_CHANNEL_ID environment variable in your .env file.');
    process.exit(1);
}
client.on('ready', () => {
    console.log(`Logged in as ${client.user.tag}!`);
    client.user.setPresence({
        status: 'online',
        activities: [{ name: 'Watching New Members', type: 3 }], // 0 = Playing, 1 = Streaming, 2 = Listening, 3 = Watching, 5 = Competing
    });
});

client.on('guildMemberAdd', (member) => {
    try {
        const welcomeChannel = client.channels.cache.get(WELCOME_CHANNEL_ID);

        // Check if the welcome channel exists. fr fr
        if (!welcomeChannel) {
            console.error(`Welcome channel with ID ${WELCOME_CHANNEL_ID} not found.`);
            return;
        }

        // Send a welcome message to the channel.
        welcomeChannel.send({
            content: `Welcome to KingCanvas Hangout, ${member.user}! `,
        });
        console.log(`Sent welcome message to ${member.user.tag} in ${welcomeChannel.name}`);

    } catch (error) {
        console.error('Error sending welcome message:', error);
    }
});

// Discord Token Log in
client.login(BOT_TOKEN).catch(error => {
    console.error('Failed to log in:', error);
});