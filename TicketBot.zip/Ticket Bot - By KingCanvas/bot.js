const { Client, GatewayIntentBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, ChannelType, PermissionsBitField, EmbedBuilder } = require('discord.js');
const dotenv = require('dotenv');

dotenv.config();

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
    ],
});

const TOKEN = process.env.DISCORD_BOT_TOKEN; // Make a file named .env and put DISCORD_BOT_TOKEN=YOUR-BOT-TOKEN
const TICKET_CATEGORY_NAME = 'Tickets';
const SUPPORT_ROLE_ID = null; // Replace with staff role (doesnt matter)
const TICKET_BUTTON_ID = 'open_support_ticket'; // Unique ID for the button
// dont mess with this please //
client.on('ready', async () => {
    console.log(`Logged in as ${client.user.tag}`);
// change this
    const guildId = 'SERVER_ID'; // Replace with your servers ID
    const channelId = 'CHANnEL_ID'; // Replace with the ID of the channel where you want the button to go

    const guild = client.guilds.cache.get(guildId);
    if (!guild) return;

    const channel = guild.channels.cache.get(channelId);
    if (!channel) return;

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(TICKET_BUTTON_ID)
                .setLabel('Open for Support')
                .setStyle(ButtonStyle.Primary),
        );

    // Check if the button message already exists to avoid sending it multiple times
    const existingMessages = await channel.messages.fetch({ limit: 100 });
    const hasButton = existingMessages.some(msg =>
        msg.author.id === client.user.id &&
        msg.components.some(row =>
            row.components.some(comp => comp.customId === TICKET_BUTTON_ID)
        )
    );
    // you can change the content of the embed below but nothing else on this part
    const ticketEmbed = new EmbedBuilder()
        .setColor(0x0099ff)
        .setTitle('Need Support?')
        .setDescription('Click the button below to open a support ticket.')
        .addFields(
            { name: 'How it works:', value: '1. Click the button.\n2. Fill out the form.\n3. A ticket channel will be created for you.' },
            { name: 'Please be patient', value: 'Our support team will get back to you as soon as possible.' },
            { name: 'Partner Ship', value: 'You can email us: teamkingcanvas@gmail.com, or open a ticket!' }
        );

    if (!hasButton) {
        try {
            await channel.send({ embeds: [ticketEmbed], components: [row] });
            console.log(`Ticket message has been sent to #${channel.name}`);
            console.log("Made By KingCanvas: Thank You for downloading my code!");
        } catch (error) {
            console.error('Error sending ticket button:', error);
        }
    }
});

client.on('interactionCreate', async interaction => {
    if (interaction.isButton() && interaction.customId === TICKET_BUTTON_ID) {
        const modal = new ModalBuilder()
            .setCustomId('ticket_modal')
    // you can change the button title if you wish
            .setTitle('Open for Support');
    // you can replace some parts of this. If you get an error got to my discord server. You can join by going to my website (https://kingcanvas.github.io/kingcanvas)
        const reasonInput = new TextInputBuilder()
            .setCustomId('ticket_reason')
            .setLabel('Why are you opening the ticket?')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('Briefly describe your issue')
            .setRequired(true);
    // same here
        const usernameInput = new TextInputBuilder()
            .setCustomId('discord_username')
            .setLabel('Your Discord Username')
            .setStyle(TextInputStyle.Short)
            .setValue(interaction.user.tag)
            .setRequired(true);
    // and here
        const additionalInfoInput = new TextInputBuilder()
            .setCustomId('additional_info')
            .setLabel('Anything else to add?')
            .setStyle(TextInputStyle.Paragraph)
            .setPlaceholder('Provide any other relevant details')
            .setRequired(false);
   // dont mess with anything else it will break the bot!
        const firstActionRow = new ActionRowBuilder().addComponents(reasonInput);
        const secondActionRow = new ActionRowBuilder().addComponents(usernameInput);
        const thirdActionRow = new ActionRowBuilder().addComponents(additionalInfoInput);

        modal.addComponents(firstActionRow, secondActionRow, thirdActionRow);

        await interaction.showModal(modal);
    } else if (interaction.isModalSubmit() && interaction.customId === 'ticket_modal') {
        const reason = interaction.fields.getTextInputValue('ticket_reason');
        const username = interaction.fields.getTextInputValue('discord_username');
        const additionalInfo = interaction.fields.getTextInputValue('additional_info');

        const guild = interaction.guild;
        let category = guild.channels.cache.find(c => c.name === TICKET_CATEGORY_NAME && c.type === ChannelType.GuildCategory);
        if (!category) {
            category = await guild.channels.create({ name: TICKET_CATEGORY_NAME, type: ChannelType.GuildCategory });
        }

        const ticketChannelName = `ticket-${interaction.user.username}`;

        const ticketChannel = await guild.channels.create({
            name: ticketChannelName,
            parent: category.id,
            type: ChannelType.GuildText,
            permissionOverwrites: [
                {
                    id: interaction.guild.id,
                    deny: [PermissionsBitField.Flags.ViewChannel],
                },
                {
                    id: interaction.user.id,
                    allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages],
                },
                {
                    id: client.user.id,
                    allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ManageChannels],
                },
                ...(SUPPORT_ROLE_ID ? [{
                    id: SUPPORT_ROLE_ID,
                    allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages],
                }] : []),
            ],
        });

        const embed = new EmbedBuilder()
            .setTitle(`New Ticket from ${interaction.user.tag}`)
	    // you can edit this part: you can set the color to anything
            .setColor(0x0099ff)
            .addFields(
                { name: 'Reason', value: reason },
                { name: 'Discord Username', value: username || interaction.user.tag },
                ...(additionalInfo ? [{ name: 'Additional Information', value: additionalInfo }] : []),
            )
            .setFooter({ text: `Ticket created by ${interaction.user.id}` })
            .setTimestamp();
	    // nothing else
        await ticketChannel.send({ content: `${interaction.user}, a new support ticket has been created.`, embeds: [embed] });
        if (SUPPORT_ROLE_ID) {
            const supportRole = await guild.roles.fetch(SUPPORT_ROLE_ID);
            if (supportRole) {
                await ticketChannel.send({ content: `${supportRole}` });
            }
        }

        await interaction.reply({ content: `Your ticket has been created in <#${ticketChannel.id}>.`, ephemeral: true });
    }
});

client.on('messageCreate', async msg => {
    if (msg.content.toLowerCase() === '!close' && msg.channel.name.startsWith('ticket-')) {
        const member = await msg.guild.members.fetch(msg.author.id);
        const hasManageChannels = member.permissionsIn(msg.channel).has('MANAGE_CHANNELS');

        if (hasManageChannels) {
            await msg.channel.delete();
        } else {
            await msg.reply('You do not have permission to close this ticket.');
        }
    }
});

client.login(TOKEN);