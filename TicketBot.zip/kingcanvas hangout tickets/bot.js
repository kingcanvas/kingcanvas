const { Client, GatewayIntentBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, ChannelType, PermissionsBitField, EmbedBuilder } = require('discord.js');
const dotenv = require('dotenv');

dotenv.config();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
  ],
});

const TOKEN = process.env.DISCORD_BOT_TOKEN;
const SUPPORT_TICKET_CATEGORY_ID = 'CategoryID'; // Category IDS
const PARTNER_REQUEST_CATEGORY_ID = 'CategoryID'; // Category IDS
const STAFF_TICKET_CATEGORY_ID = 'CategoryID'; // Category IDS
const SUPPORT_ROLE_ID = null;
const TICKET_BUTTON_ID = 'open_support_ticket';
const PARTNER_BUTTON_ID = 'request_partnership';
const STAFF_BUTTON_ID = 'staff';

client.on('ready', async () => {
  console.log(`Logged in as ${client.user.tag}`);
  const guildId = 'Server id'; // Server id
  const channelId = 'ticket message channel'; // ticket message channel

  const guild = client.guilds.cache.get(guildId);
  if (!guild) return;

  const channel = guild.channels.cache.get(channelId);
  if (!channel) return;

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId(TICKET_BUTTON_ID)
        .setLabel('Open for Support')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(PARTNER_BUTTON_ID)
        .setLabel('Request Partnership')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(STAFF_BUTTON_ID)
        .setLabel('Apply For Staff')
        .setStyle(ButtonStyle.Danger)
    );

  const existingMessages = await channel.messages.fetch({ limit: 100 });
  const hasButtons = existingMessages.some(msg =>
    msg.author.id === client.user.id &&
    msg.components.some(row =>
      row.components.some(comp => comp.customId === TICKET_BUTTON_ID || comp.customId === PARTNER_BUTTON_ID || comp.customId === STAFF_BUTTON_ID)
    )
  );

  const ticketEmbed = new EmbedBuilder()
    .setColor(0x0099ff)
    // You can change this. If you have errors open a ticket in my discord.
    .setTitle('Need Support?')
    .setDescription('Click the button below to open a support ticket.')
    .addFields(
      { name: 'How it works:', value: '1. Click the button (Partner, support, or staff).\n2. Fill out the form.\n3. A ticket channel will be created for you.' },
      { name: 'Please be patient', value: 'Our support team will get back to you as soon as possible.' },
      { name: 'Partner Ship', value: 'You can email us: teamkingcanvas@gmail.com, or open a ticket!' }
    );
    // Dont change anything else on thispart unless i say.
  if (!hasButtons) {
    try {
      await channel.send({ embeds: [ticketEmbed], components: [row] });
      console.log(`Buttons sent to #${channel.name}`);
    } catch (error) {
      console.error('Error sending buttons:', error);
    }
  }
});

client.on('interactionCreate', async interaction => {
  if (interaction.isButton()) {
    if (interaction.customId === TICKET_BUTTON_ID) {
      await interaction.deferReply({ ephemeral: true });

      const guild = interaction.guild;
      const categoryId = SUPPORT_TICKET_CATEGORY_ID;
      console.log(`Attempting to fetch Support Category with ID: ${categoryId}`);
      const category = guild.channels.cache.get(categoryId);
      console.log(`Support Category fetched:`, category);

      if (!category || category.type !== ChannelType.GuildCategory) {
        return await interaction.followUp({ content: `Error: Support Category not found or is invalid. (ID: ${categoryId})`, ephemeral: true }); // Use followUp
      }

      const ticketChannelName = `ticket-${interaction.user.username}`;

      const ticketChannel = await guild.channels.create({
        name: ticketChannelName,
        parent: categoryId,
        type: ChannelType.GuildText,
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: [PermissionsBitField.Flags.ViewChannel],
          },
          {
            id: interaction.user.id,
            allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages],
          },
          {
            id: client.user.id,
            allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ManageChannels],
          },
          ...(SUPPORT_ROLE_ID ? [{
            id: SUPPORT_ROLE_ID,
            allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages],
          }] : []),
        ],
      });
      // You can edit here.
      const embed = new EmbedBuilder()
        .setTitle(`New Support Ticket from ${interaction.user.tag}`)
        .setColor(0x0099ff)
        .setDescription('Please describe your issue here. Our support team will be with you shortly.')
        .setFooter({ text: `Ticket created by ${interaction.user.id}` })
        .setTimestamp();

      await ticketChannel.send({ content: `${interaction.user}, Welcome to your support ticket!`, embeds: [embed] });
      await interaction.followUp({ content: `Your support ticket has been created in <#${ticketChannel.id}>. You will be redirected there.`, ephemeral: true }); // Use followUp
    
    } else if (interaction.customId === PARTNER_BUTTON_ID) {

      const guild = interaction.guild;
      const categoryId = PARTNER_REQUEST_CATEGORY_ID;
      console.log(`Attempting to fetch Partner Category with ID: ${categoryId}`);
      const category = guild.channels.cache.get(categoryId);
      console.log(`Partner Category fetched:`, category);

      if (!category || category.type !== ChannelType.GuildCategory) {
        return await interaction.followUp({ content: `Error: Partnership Request category not found or is invalid. (ID: ${categoryId})`, ephemeral: true });
      }

      const modal = new ModalBuilder()
        .setCustomId('partner_request_modal')
        .setTitle('Partnership Inquiry');

      const servernameInput = new TextInputBuilder()
        .setCustomId('server_name')
        .setLabel('Your Server/Community Name')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

      const contactEmailInput = new TextInputBuilder()
        .setCustomId('contact_email')
        .setLabel('Contact Email')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

      const partnershipDetailsInput = new TextInputBuilder()
        .setCustomId('partnership_details')
        .setLabel('Describe your partnership proposal')
        .setStyle(TextInputStyle.Paragraph)
        .setPlaceholder('Please provide details about your partnership idea')
        .setRequired(true);

      const usernameInput = new TextInputBuilder()
        .setCustomId('discord_username')
        .setLabel('Your Discord Username')
        .setStyle(TextInputStyle.Short)
        .setValue(interaction.user.tag)
        .setRequired(true);

      const firstActionRow = new ActionRowBuilder().addComponents(servernameInput);
      const secondActionRow = new ActionRowBuilder().addComponents(contactEmailInput);
      const thirdActionRow = new ActionRowBuilder().addComponents(partnershipDetailsInput);
      const fourthActionRow = new ActionRowBuilder().addComponents(usernameInput);

      modal.addComponents(firstActionRow, secondActionRow, thirdActionRow, fourthActionRow);

      await interaction.showModal(modal);
    } else if (interaction.customId === STAFF_BUTTON_ID) {

      const guild = interaction.guild;
      const categoryId = STAFF_TICKET_CATEGORY_ID;
      console.log(`Attempting to fetch Staff Apply with ID: ${categoryId}`);
      const category = guild.channels.cache.get(categoryId);
      console.log(`Staff Category fetched:`, category);

      if (!category || category.type !== ChannelType.GuildCategory) {
        return await interaction.followUp({ content: `Error: Staff Apply category not found or is invalid. (ID: ${categoryId})`, ephemeral: true });
      }

      const modal = new ModalBuilder()
        .setCustomId('staff_modal')
        .setTitle('Staff Apply');

      const whyInput = new TextInputBuilder()
        .setCustomId('why')
        .setLabel('Why do you want to be a staff member')
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(true);

      const ageInput = new TextInputBuilder()
        .setCustomId('age')
        .setLabel('How old are you')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

      const howInput = new TextInputBuilder()
        .setCustomId('how')
        .setLabel('How will you help us.')
        .setStyle(TextInputStyle.Paragraph)
        .setPlaceholder('Tell us how you will help us.')
        .setRequired(true);

      const usernameInput = new TextInputBuilder()
        .setCustomId('discord_username')
        .setLabel('Your Discord Username')
        .setStyle(TextInputStyle.Short)
        .setValue(interaction.user.tag)
        .setRequired(true);

      const firstActionRow = new ActionRowBuilder().addComponents(whyInput);
      const secondActionRow = new ActionRowBuilder().addComponents(ageInput);
      const thirdActionRow = new ActionRowBuilder().addComponents(howInput);
      const fourthActionRow = new ActionRowBuilder().addComponents(usernameInput);

      modal.addComponents(firstActionRow, secondActionRow, thirdActionRow, fourthActionRow);

      await interaction.showModal(modal);
    }
  } else if (interaction.isModalSubmit()) {
    if (interaction.customId === 'partner_request_modal') {
      await interaction.deferReply({ ephemeral: true });

      const serverName = interaction.fields.getTextInputValue('server_name');
      const contactEmail = interaction.fields.getTextInputValue('contact_email');
      const partnershipDetails = interaction.fields.getTextInputValue('partnership_details');
      const username = interaction.fields.getTextInputValue('discord_username');

      const guild = interaction.guild;
      const categoryId = PARTNER_REQUEST_CATEGORY_ID;
      const category = guild.channels.cache.get(categoryId);

      if (!category || category.type !== ChannelType.GuildCategory) {
        return await interaction.followUp({ content: 'Error: Partnership Request category not found or is invalid.', ephemeral: true });
      }

      const ticketChannelName = `partner-${interaction.user.username}`;

      const ticketChannel = await guild.channels.create({
        name: ticketChannelName,
        parent: categoryId,
        type: ChannelType.GuildText,
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: [PermissionsBitField.Flags.ViewChannel],
          },
          {
            id: interaction.user.id,
            allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages],
          },
          {
            id: client.user.id,
            allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ManageChannels],
          },
        ],
      });

      const embed = new EmbedBuilder()
        .setTitle(`New Partnership Inquiry from ${interaction.user.tag}`)
        .setColor(0x008000)
        .addFields(
          { name: 'Server/Community Name', value: serverName },
          { name: 'Contact Email', value: contactEmail },
          { name: 'Partnership Proposal', value: partnershipDetails },
          { name: 'Discord Username', value: username || interaction.user.tag },
        )
        .setFooter({ text: `Partnership inquiry by ${interaction.user.id}` })
        .setTimestamp();

      await ticketChannel.send({
        content: `${interaction.user}, Thank you for your partnership inquiry! Please provide any initial details here.`,
        embeds: [embed]
      });

      await interaction.followUp({ content: `Your partnership inquiry has been submitted in <#${ticketChannel.id}>.`, ephemeral: true });
    } else if (interaction.customId === 'staff_modal') {
      await interaction.deferReply({ ephemeral: true }); // Acknowledge

      const Why = interaction.fields.getTextInputValue('why');
      const Age = interaction.fields.getTextInputValue('age');
      const How = interaction.fields.getTextInputValue('how');
      const username = interaction.fields.getTextInputValue('discord_username');

      const guild = interaction.guild;
      const categoryId = STAFF_TICKET_CATEGORY_ID;
      const category = guild.channels.cache.get(categoryId);

      if (!category || category.type !== ChannelType.GuildCategory) {
        return await interaction.followUp({ content: 'Error: Staff Apply category not found or is invalid.', ephemeral: true });
      }

      const ticketChannelName = `staff-${interaction.user.username}`;

      const ticketChannel = await guild.channels.create({
        name: ticketChannelName,
        parent: categoryId,
        type: ChannelType.GuildText,
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: [PermissionsBitField.Flags.ViewChannel],
          },
          {
            id: interaction.user.id,
            allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages],
          },
          {
            id: client.user.id,
            allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ManageChannels],
          },
        ],
      });

      const embed = new EmbedBuilder()
        .setTitle(`New Staff Apply from ${interaction.user.tag}`)
        .setColor(0xFF0000)
        .addFields(
          { name: 'Why do you want to be staff', value: Why },
          { name: 'How old are you', value: Age },
          { name: 'How would you help', value: How },
          { name: 'Discord Username', value: username || interaction.user.tag },
        )
        .setFooter({ text: `Staff apply by ${interaction.user.id}` })
        .setTimestamp();

      await ticketChannel.send({
        content: `${interaction.user}, Thank you for your staff apply! Please wait for staff to reply.`,
        embeds: [embed]
      });

      await interaction.followUp({ content: `Your staff apply has been submitted in <#${ticketChannel.id}>.`, ephemeral: true });
    }
  }
});

client.on('messageCreate', async msg => {
  if (msg.content.toLowerCase() === '!close' && (msg.channel.name.startsWith('ticket-') || msg.channel.name.startsWith('partner-') || msg.channel.name.startsWith('staff-'))) {
    const member = await msg.guild.members.fetch(msg.author.id);
    const hasManageChannels = member.permissionsIn(msg.channel).has('MANAGE_CHANNELS');

    if (hasManageChannels) {
      await msg.channel.delete();
    } else {
      await msg.reply('You do not have permission to close this channel.');
    }
  }
});

client.login(TOKEN);
